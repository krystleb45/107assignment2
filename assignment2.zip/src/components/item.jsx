
import "./item.css";
import QuantityPicker from "./quantityPicker";

const Item = () => {
//state

//function

const handleAdd = () => {
    console.log("Adding item to cart")

}

//return
    return (
        <div className="item">

            <img src="https://picsum.photos/200/300" alt="product" />

            <h5>Title Here</h5>

            <label className="total">$ Total</label>
            <label className="price">$ Price</label>

            <div className="controls">

            <QuantityPicker />

            <button onClick={handleAdd} className="btn btn-sm btn-dark"> Add</button>
            </div>
        </div>
    );
};

export default Item;
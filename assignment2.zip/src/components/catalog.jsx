import "./catalog.css";
import Item from "./item";


const Catalog = () => {
    return(
        <div className="catalog">
        <h3>Our amazing Catalog</h3>
        <Item></Item>
        <Item></Item>
        <Item></Item>
        <Item></Item>
        <Item></Item>
        <Item></Item>
        <Item></Item>
        </div>
    );
};
export default Catalog;